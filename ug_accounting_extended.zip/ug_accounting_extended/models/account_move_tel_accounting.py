from odoo import models, fields, api


class AccountMove(models.Model):
    _inherit = 'account.move'

    amount_in_words = fields.Char(string="Amount in Words", compute='_compute_amount_in_words', store=True)

    @api.depends('amount_total')
    def _compute_amount_in_words(self):
        for move in self:
            move.amount_in_words = self._convert_amount_to_words(move.amount_total)

    def _convert_amount_to_words(self, amount):
        # Round to two decimal places
        amount = round(amount, 2)

        # Separate the amount into Riyals and Halalas
        riyals = int(amount)
        halalas = int((amount - riyals) * 100)

        # Convert to words (simple English format)
        riyals_word = f"{riyals} Riyal" if riyals == 1 else f"{riyals} Riyals"
        halalas_word = f"{halalas} Halala" if halalas == 1 else f"{halalas} Halalas"

        # Combine the results
        if halalas > 0:
            return f"{riyals_word}, {halalas_word}"
        else:
            return riyals_word
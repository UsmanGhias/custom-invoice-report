{
    'name': 'Accounting Extended (UsmanGhias)',
    'version': '1.0',
    'summary': 'Customized Invoice and Accounting Reports',
    'description': """
    This module provides customized invoice templates and accounting features for the Accounting system. Developed by Usman Ghias
    Contact No: +923126912440, GitHub Name: UsmanGhias
    """,
    'category': 'Accounting',
    'author': 'Usman Ghias',
    'depends': ['account', 'sale'],
    'data': [
        # 'views/account_move_tel_accounting_view.xml',
        'reports/report_invoice_en.xml',
        'reports/reports.xml',
        'reports/report_invoice.xml',
        'reports/header_footer_invoice.xml',
        'reports/header_footer_invoice_en.xml',
    ],
    'installable': True,
    'auto_install': False,
}
